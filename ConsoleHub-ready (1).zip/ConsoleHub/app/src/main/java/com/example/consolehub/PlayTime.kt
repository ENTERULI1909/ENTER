package com.example.consolehub

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/**
 * Считает время в приложениях по событиям UsageStatsManager и копит итог у себя:
 * система хранит события лишь около недели, а нам нужна общая сумма.
 * При первом запуске берётся последняя неделя, дальше считается всё новое.
 */
class PlayTime(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("playtime", Context.MODE_PRIVATE)
    private val day = 24L * 60 * 60 * 1000

    @Suppress("DEPRECATION")
    fun hasAccess(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Возвращает: пакет → суммарное время (мс), пакет → время последнего выхода из приложения. */
    fun sync(): Pair<Map<String, Long>, Map<String, Long>> {
        if (hasAccess()) {
            val now = System.currentTimeMillis()
            val from = prefs.getLong("last", now - 7 * day)
            val open = HashMap<String, Long>() // сессии, начатые, но ещё не закрытые
            prefs.all.forEach { (k, v) -> if (k.startsWith("o:") && v is Long) open[k.substring(2)] = v }
            val added = HashMap<String, Long>()
            val last = HashMap<String, Long>()

            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                val pkg = e.packageName ?: continue
                if (pkg == ctx.packageName) continue
                if (e.eventType == FOREGROUND) {
                    open[pkg] = e.timeStamp
                } else if (e.eventType == BACKGROUND) {
                    val start = open.remove(pkg)
                    if (start != null) {
                        added[pkg] = (added[pkg] ?: 0L) + (e.timeStamp - start).coerceAtLeast(0L)
                        last[pkg] = e.timeStamp
                    }
                }
            }

            val ed = prefs.edit()
            prefs.all.keys.filter { it.startsWith("o:") }.forEach { ed.remove(it) }
            open.forEach { (p, s) -> ed.putLong("o:$p", s) }
            added.forEach { (p, ms) -> ed.putLong("t:$p", prefs.getLong("t:$p", 0L) + ms) }
            last.forEach { (p, ts) -> ed.putLong("l:$p", ts) }
            ed.putLong("last", now).apply()
        }
        val total = HashMap<String, Long>()
        val lastPlayed = HashMap<String, Long>()
        prefs.all.forEach { (k, v) ->
            if (v is Long) {
                if (k.startsWith("t:")) total[k.substring(2)] = v
                else if (k.startsWith("l:")) lastPlayed[k.substring(2)] = v
            }
        }
        return total to lastPlayed
    }

    private companion object {
        const val FOREGROUND = 1 // MOVE_TO_FOREGROUND / ACTIVITY_RESUMED
        const val BACKGROUND = 2 // MOVE_TO_BACKGROUND / ACTIVITY_PAUSED
    }
}
