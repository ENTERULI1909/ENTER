package com.example.consolehub

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Стартовый экран, как «заставка» консоли: профиль, время и «нажми любую кнопку». */
@Composable
fun SplashScreen(vm: LauncherViewModel) {
    val clock by rememberClock()
    val date by rememberClock("EEEE, d MMMM")
    val pulse = rememberInfiniteTransition(label = "splash")
    val blink by pulse.animateFloat(0.3f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "blink")
    val ring by pulse.animateColor(Cyan, Coral, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "ring")
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF26262A), Color(0xFF141416))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.begin() },
    ) {
        // Полосы по краям, как контроллеры по бокам консоли
        Box(Modifier.align(Alignment.CenterStart).width(10.dp).fillMaxHeight(0.55f).background(Cyan, RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp)))
        Box(Modifier.align(Alignment.CenterEnd).width(10.dp).fillMaxHeight(0.55f).background(Coral, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp)))
        Column(Modifier.align(Alignment.TopCenter).padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(clock.first, color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text(date.first, color = Dim, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(vm, 104.dp, ring)
            Spacer(Modifier.height(14.dp))
            Text(vm.nick, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(
            "Нажми любую кнопку или коснись экрана",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 26.dp).alpha(blink),
            color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
        )
        Text(
            "🔋 ${clock.second}%", modifier = Modifier.align(Alignment.TopEnd).padding(20.dp),
            color = Dim, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

/** Игра «вырастает» из плитки на весь экран и затемняется, потом открывается сама игра. */
@Composable
fun LaunchOverlay(vm: LauncherViewModel, l: Launching) {
    val p = remember(l) { Animatable(0f) }
    LaunchedEffect(l) {
        p.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
        vm.finishLaunch()
    }
    val e = p.value
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val r = if (l.bounds.width > 1f) l.bounds else Rect(w * 0.4f, h * 0.3f, w * 0.6f, h * 0.7f)
        val cover = vm.covers[l.app.pkg]
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = e * 0.9f)))
        Box(
            Modifier
                .offset { IntOffset(mix(r.left, 0f, e).roundToInt(), mix(r.top, 0f, e).roundToInt()) }
                .size(with(density) { mix(r.width, w, e).toDp() }, with(density) { mix(r.height, h, e).toDp() })
                .clip(RoundedCornerShape(mix(6f, 0f, e).dp)).background(tileBrush(l.app.pkg)),
            contentAlignment = Alignment.Center,
        ) {
            if (cover != null) Image(cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Image(l.app.icon, null, Modifier.fillMaxSize(mix(0.6f, 0.3f, e)))
        }
        // В самом конце уходим в чёрный, чтобы открытие игры было незаметным
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = ((e - 0.6f) / 0.4f).coerceIn(0f, 1f))))
    }
}

@Composable
fun SheetOverlay(vm: LauncherViewModel, app: AppItem) {
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.closeSheet() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.width(360.dp).clip(RoundedCornerShape(18.dp)).background(Panel)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(app.label, color = Color.White, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(
                "Время игры: ${fmtTime(vm.playMs[app.pkg] ?: 0L)}  ·  ${fmtAgo(vm.lastPlayed[app.pkg] ?: 0L)}",
                color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            vm.sheetItems.forEachIndexed { i, item ->
                val focused = vm.padActive && i == vm.sheetIndex
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF4A4A4E))
                        .then(if (focused) Modifier.border(3.dp, Cyan, RoundedCornerShape(12.dp)) else Modifier)
                        .clickable { vm.runSheet(i) }.padding(13.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(item.first, color = Color.White, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun SRow(vm: LauncherViewModel, i: Int, onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF4A4A4E))
            .then(if (vm.padActive && vm.settingsIndex == i) Modifier.border(3.dp, Cyan, RoundedCornerShape(12.dp)) else Modifier)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/** Профиль: ник, иконка игрока, доступ к статистике, раскладка кнопок. */
@Composable
fun SettingsScreen(vm: LauncherViewModel) {
    val fr = remember { FocusRequester() }
    val focus = LocalFocusManager.current
    LaunchedEffect(vm.nickFocusTick) { if (vm.nickFocusTick > 0) fr.requestFocus() }
    Box(
        Modifier.fillMaxSize().background(Color(0xE61C1C1E))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.closeSettings() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.windowInsetsPadding(WindowInsets.safeDrawing).widthIn(max = 480.dp).fillMaxWidth(0.92f)
                .verticalScroll(rememberScrollState())
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .padding(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Профиль", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)

            SRow(vm, 0, null) {
                Avatar(vm, 44.dp)
                Spacer(Modifier.width(12.dp))
                BasicTextField(
                    value = vm.nick, onValueChange = { vm.setNick(it) }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold),
                    cursorBrush = SolidColor(Cyan),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                    modifier = Modifier.weight(1f).focusRequester(fr).onFocusChanged { vm.typing = it.isFocused },
                    decorationBox = { inner ->
                        Column {
                            Text("Ник", color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            inner()
                        }
                    },
                )
            }

            SRow(vm, 1, null) {
                Column(Modifier.weight(1f)) {
                    Text("Иконка игрока", color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        EMOJIS.forEach { em ->
                            val on = vm.avatar == null && vm.emoji == em
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).background(Circle)
                                    .then(if (on) Modifier.border(2.dp, Cyan, CircleShape) else Modifier)
                                    .clickable { vm.setEmoji(em) },
                                contentAlignment = Alignment.Center,
                            ) { Text(em, fontSize = 20.sp) }
                        }
                    }
                }
            }

            SRow(vm, 2, { if (vm.avatar != null) vm.removeAvatarPhoto() else vm.avatarRequest++ }) {
                Text(
                    if (vm.avatar != null) "Убрать фото и вернуть эмодзи" else "Своё фото из галереи",
                    color = Color.White, fontWeight = FontWeight.ExtraBold,
                )
            }

            SRow(vm, 3, { vm.usageRequest++ }) {
                Column {
                    Text("Время игры", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (vm.hasUsage) "Доступ к статистике включён" else "Выключено: нажми и разреши доступ для Console Hub",
                        color = if (vm.hasUsage) Cyan else Coral, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }

            SRow(vm, 4, { vm.toggleSwap() }) {
                Column {
                    Text("Раскладка кнопок A/B", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (vm.swapAB) "Как у Nintendo: A справа" else "Как у Xbox: A снизу",
                        color = Dim, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }

            SRow(vm, 5, { vm.closeSettings() }) {
                Text("Готово", color = Color.White, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
