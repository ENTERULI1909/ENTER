package com.example.consolehub

import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SoundEffectConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()
    private var pendingCover: String? = null
    private var lastDir = 0

    private val coverPicker = registerForActivityResult(PickVisualMedia()) { uri ->
        val pkg = pendingCover
        if (uri != null && pkg != null) vm.setCover(pkg, uri)
    }
    private val avatarPicker = registerForActivityResult(PickVisualMedia()) { uri ->
        if (uri != null) vm.setAvatarPhoto(uri)
    }

    // Обновляем список, когда приложения ставят или удаляют
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = vm.refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        vm.onTick = {
            window.decorView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            window.decorView.playSoundEffect(SoundEffectConstants.CLICK)
        }
        // Игра открывается с плавным появлением
        vm.starter = { i ->
            startActivity(
                i,
                ActivityOptions.makeCustomAnimation(this@MainActivity, android.R.anim.fade_in, android.R.anim.fade_out).toBundle(),
            )
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LaunchedEffect(vm.coverRequest) {
                    vm.coverRequest?.let {
                        pendingCover = it
                        vm.coverRequest = null
                        coverPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
                    }
                }
                LaunchedEffect(vm.avatarRequest) {
                    if (vm.avatarRequest > 0) avatarPicker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly))
                }
                LaunchedEffect(vm.usageRequest) {
                    if (vm.usageRequest > 0) openUsageSettings()
                }
                LauncherRoot(vm)
            }
        }
    }

    private fun openUsageSettings() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    /** Кнопки геймпада и клавиатуры. Стрелки при удержании повторяются сами. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action != KeyEvent.ACTION_DOWN || vm.typing) return super.dispatchKeyEvent(e)
        val okKey = if (vm.swapAB) KeyEvent.KEYCODE_BUTTON_B else KeyEvent.KEYCODE_BUTTON_A
        val backKey = if (vm.swapAB) KeyEvent.KEYCODE_BUTTON_A else KeyEvent.KEYCODE_BUTTON_B
        val dir: Act? = when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> Act.Left
            KeyEvent.KEYCODE_DPAD_RIGHT -> Act.Right
            KeyEvent.KEYCODE_DPAD_UP -> Act.Up
            KeyEvent.KEYCODE_DPAD_DOWN -> Act.Down
            else -> null
        }
        val btn: Act? = when (e.keyCode) {
            okKey, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> Act.Ok
            backKey, KeyEvent.KEYCODE_ESCAPE -> Act.Back
            KeyEvent.KEYCODE_BUTTON_X -> Act.Alt
            KeyEvent.KEYCODE_BUTTON_Y -> Act.Sort
            KeyEvent.KEYCODE_BUTTON_L1 -> Act.Prev
            KeyEvent.KEYCODE_BUTTON_R1 -> Act.Next
            else -> null
        }
        // Стартовый экран: подойдёт любая кнопка геймпада или стрелка
        if (!vm.started) {
            if (dir != null || btn != null || KeyEvent.isGamepadButton(e.keyCode)) {
                if (e.repeatCount == 0) vm.begin()
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        if (dir != null) { vm.act(dir); return true }
        if (btn != null && e.repeatCount == 0) { vm.act(btn); return true }
        return super.dispatchKeyEvent(e)
    }

    /** Аналоговый стик и «крестовина», которая приходит как HAT-ось. */
    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != 0 && e.action == MotionEvent.ACTION_MOVE && !vm.typing) {
            val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val x = if (hx != 0f) hx else e.getAxisValue(MotionEvent.AXIS_X)
            val y = if (hy != 0f) hy else e.getAxisValue(MotionEvent.AXIS_Y)
            val dir = when {
                x < -0.5f -> 1
                x > 0.5f -> 2
                y < -0.5f -> 3
                y > 0.5f -> 4
                else -> 0
            }
            if (dir != 0 && dir != lastDir) {
                vm.act(when (dir) { 1 -> Act.Left; 2 -> Act.Right; 3 -> Act.Up; else -> Act.Down })
            }
            lastDir = dir
            return true
        }
        return super.onGenericMotionEvent(e)
    }
}
