package com.example.consolehub

import android.content.Context
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColor
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sign

internal val Cyan = Color(0xFF00C3E3)
internal val Coral = Color(0xFFFF4554)
internal val Dim = Color(0xFF9A9AA0)
internal val Circle = Color(0xFF3D3D40)
internal val Panel = Color(0xFF3A3A3D)

internal fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t

internal fun tileBrush(pkg: String): Brush {
    val hue = (abs(pkg.hashCode()) % 360).toFloat()
    return Brush.linearGradient(listOf(Color.hsv(hue, 0.55f, 0.6f), Color.hsv(hue, 0.6f, 0.25f)))
}

/** Время и заряд батареи, обновляются раз в 10 секунд. */
@Composable
fun rememberClock(pattern: String = "HH:mm"): State<Pair<String, Int>> {
    val ctx = LocalContext.current
    val s = remember { mutableStateOf("" to 0) }
    LaunchedEffect(Unit) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val fmt = SimpleDateFormat(pattern, Locale.getDefault())
        while (true) {
            s.value = fmt.format(Date()) to bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            delay(10_000)
        }
    }
    return s
}

@Composable
fun Avatar(vm: LauncherViewModel, size: Dp, ring: Color = Cyan, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(CircleShape).background(Color(0xFF555555)).border(2.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        val img = vm.avatar
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(vm.emoji, fontSize = (size.value * 0.5f).sp)
    }
}

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    BackHandler(enabled = vm.started && (vm.settingsOpen || vm.inLib || vm.sheet != null)) { vm.act(Act.Back) }
    // Плавное появление при каждом возврате в приложение (в том числе из игры)
    val fade = remember { Animatable(0f) }
    LaunchedEffect(vm.resumeTick) { fade.snapTo(0f); fade.animateTo(1f, tween(450)) }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF2C2C2E), Color(0xFF1C1C1E))))
            // Любое касание выключает режим «геймпад»: рамка фокуса пропадает
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) { awaitPointerEvent(PointerEventPass.Initial); vm.padActive = false }
                }
            }
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }) {
            AnimatedContent(
                targetState = vm.started, label = "root",
                transitionSpec = { fadeIn(tween(500)) togetherWith fadeOut(tween(300)) },
            ) { started -> if (started) MainScreen(vm) else SplashScreen(vm) }
            vm.sheet?.let { SheetOverlay(vm, it) }
            if (vm.settingsOpen) SettingsScreen(vm)
        }
        vm.launching?.let { LaunchOverlay(vm, it) }
        vm.message?.let { m ->
            Text(
                m,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp)
                    .clip(RoundedCornerShape(50)).background(Color.White)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                color = Color(0xFF111111), fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
fun MainScreen(vm: LauncherViewModel) {
    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        TopBar(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AnimatedContent(
                targetState = vm.inLib, label = "screen",
                transitionSpec = {
                    if (targetState) slideInVertically { it } togetherWith slideOutVertically { -it }
                    else slideInVertically { -it } togetherWith slideOutVertically { it }
                },
            ) { lib -> if (lib) LibraryScreen(vm) else HomeScreen(vm) }
        }
        HintBar(vm.inLib)
    }
}

@Composable
fun TopBar(vm: LauncherViewModel) {
    val clock by rememberClock()
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).clickable { vm.openSettings() }.padding(end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(vm, 32.dp)
            Spacer(Modifier.width(8.dp))
            Text(vm.nick, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("${clock.first}   🔋 ${clock.second}%", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

@Composable
fun HintBar(inLib: Boolean) {
    val items = if (inLib) listOf("A" to "Запустить", "X" to "Меню", "Y" to "Сортировка", "LR" to "Буквы", "B" to "Назад")
    else listOf("A" to "Запустить", "◀▶" to "Выбрать", "▼" to "Библиотека", "Y" to "Профиль")
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        items.forEach { (key, label) ->
            Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.defaultMinSize(minWidth = 22.dp, minHeight = 22.dp).clip(CircleShape)
                        .background(Color(0xFFECECEC)).padding(horizontal = 5.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(key, color = Color(0xFF222222), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.width(6.dp))
                Text(label, color = Dim, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** Плитка: название сверху, квадрат с обложкой или иконкой, при желании подпись снизу. */
@Composable
fun GameTile(
    app: AppItem,
    cover: ImageBitmap?,
    selected: Boolean,
    starred: Boolean,
    sub: String?,
    modifier: Modifier,
    onBounds: (Rect) -> Unit,
    onTap: (Rect) -> Unit,
    onHold: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 1.1f else 1f, label = "scale")
    val ring = if (selected)
        rememberInfiniteTransition(label = "ring")
            .animateColor(Cyan, Color.White, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "c").value
    else Color.Transparent
    var rect by remember { mutableStateOf(Rect.Zero) }
    Column(
        modifier.pointerInput(app.pkg) { detectTapGestures(onTap = { onTap(rect) }, onLongPress = { onHold() }) },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            app.label, color = if (selected) Color.White else Dim,
            fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .onGloballyPositioned { rect = it.boundsInRoot(); onBounds(rect) }
                .clip(RoundedCornerShape(6.dp)).background(tileBrush(app.pkg))
                .then(if (selected) Modifier.border(4.dp, ring, RoundedCornerShape(6.dp)) else Modifier),
            contentAlignment = Alignment.Center,
        ) {
            if (cover != null) Image(cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Image(app.icon, null, Modifier.fillMaxSize(0.6f))
            if (starred) Text("★", modifier = Modifier.align(Alignment.TopEnd).padding(6.dp), color = Color(0xFFFFD54F))
        }
        if (sub != null) Text(sub, color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val state = rememberLazyListState()
    val home = vm.home
    val sel = vm.homeSel
    LaunchedEffect(sel, home.size) { if (home.isNotEmpty()) state.animateScrollToItem(sel) }
    BoxWithConstraints(
        Modifier.fillMaxSize().pointerInput(Unit) {
            // Свайп вверх открывает библиотеку
            var total = 0f
            detectVerticalDragGestures(
                onDragStart = { total = 0f },
                onDragEnd = { if (total < -80f) vm.openLibrary() },
                onDrag = { _, d -> total += d },
            )
        }
    ) {
        val tile = (maxHeight * 0.42f).coerceIn(96.dp, 150.dp)
        LazyRow(
            state = state,
            userScrollEnabled = false, // ленту двигаем сами: выбор всегда по центру
            contentPadding = PaddingValues(horizontal = (maxWidth - tile) / 2, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.align(Alignment.Center).pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (abs(total) > 30f) vm.moveHome(-total.sign.toInt() * maxOf(1, (abs(total) / 100f).roundToInt()))
                    },
                    onDrag = { _, d -> total += d },
                )
            },
        ) {
            itemsIndexed(home, key = { _, a -> a.pkg }) { i, app ->
                GameTile(
                    app, vm.covers[app.pkg], i == sel, false, null, Modifier.width(tile),
                    onBounds = { if (i == sel) vm.selBounds = it },
                    onTap = { b -> if (i == sel) vm.start(app, b) else vm.selectHome(i) },
                    onHold = { vm.openSheet(app) },
                )
            }
        }
        // Инфо о выбранной игре, как на консоли
        home.getOrNull(sel)?.let { cur ->
            Text(
                "Время игры: ${fmtTime(vm.playMs[cur.pkg] ?: 0L)}   ·   Запуск: ${fmtAgo(vm.lastPlayed[cur.pkg] ?: 0L)}",
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp),
                color = Dim, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
fun LibraryScreen(vm: LauncherViewModel) {
    val state = rememberLazyGridState()
    val lib = vm.library
    val homeSet = vm.homePkgs().toSet()
    var lastJump by remember { mutableIntStateOf(vm.libJumpTick) }
    // Свайп вниз с самого верха списка возвращает на главный экран
    val conn = remember {
        object : NestedScrollConnection {
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 60f && source == NestedScrollSource.UserInput) vm.closeLibrary()
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(vm.sortMode) { state.scrollToItem(0) }
    LaunchedEffect(vm.libIndex, vm.libJumpTick) {
        if (vm.libJumpTick != lastJump) {
            lastJump = vm.libJumpTick
            state.animateScrollToItem(vm.libIndex) // прыжок по букве
        } else if (vm.padActive) {
            // Геймпад: прокручиваем вслед за рамкой выбора
            val info = state.layoutInfo
            val cur = info.visibleItemsInfo.firstOrNull { it.index == vm.libIndex }
            val full = cur != null && cur.offset.y >= 0 && cur.offset.y + cur.size.height <= info.viewportEndOffset
            if (!full) state.animateScrollToItem((vm.libIndex - COLS).coerceAtLeast(0))
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Вся библиотека", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.weight(1f))
            SortMode.values().forEach { m ->
                Text(
                    m.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(end = 6.dp).clip(RoundedCornerShape(50))
                        .background(if (m == vm.sortMode) Color(0xFF00788A) else Circle)
                        .clickable { vm.setSort(m) }.padding(horizontal = 12.dp, vertical = 7.dp),
                )
            }
            Spacer(Modifier.width(6.dp))
            Button(
                onClick = { vm.closeLibrary() },
                colors = ButtonDefaults.buttonColors(containerColor = Circle, contentColor = Color.White),
            ) { Text("Назад") }
        }
        Row(Modifier.fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(COLS),
                state = state,
                modifier = Modifier.weight(1f).fillMaxHeight().nestedScroll(conn),
                contentPadding = PaddingValues(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                itemsIndexed(lib, key = { _, a -> a.pkg }) { i, app ->
                    val sel = vm.padActive && i == vm.libIndex
                    GameTile(
                        app, vm.covers[app.pkg], sel, app.pkg in homeSet, fmtTime(vm.playMs[app.pkg] ?: 0L), Modifier,
                        onBounds = { if (sel) vm.selBounds = it },
                        onTap = { b -> vm.start(app, b) },
                        onHold = { vm.openSheet(app) },
                    )
                }
            }
            // Алфавитная полоса: нажми на букву, чтобы перейти к ней
            if (vm.sortMode == SortMode.Alpha && lib.isNotEmpty()) {
                val cur = lib.getOrNull(vm.libIndex)?.let { letterOf(it) }
                Column(
                    Modifier.fillMaxHeight().padding(start = 4.dp).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    vm.groupStarts.forEach { s ->
                        val ch = letterOf(lib[s])
                        Text(
                            ch.toString(), color = if (ch == cur) Cyan else Dim,
                            fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.clickable { vm.jumpTo(s) }.padding(horizontal = 6.dp, vertical = 3.dp),
                        )
                    }
                }
            }
        }
    }
}
