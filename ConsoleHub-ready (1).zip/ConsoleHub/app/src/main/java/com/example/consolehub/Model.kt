package com.example.consolehub

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

const val COLS = 6          // столбцов в библиотеке
const val SETTINGS_ROWS = 6 // строк в настройках профиля

val EMOJIS = listOf("🙂", "😎", "🦊", "🐱", "🐼", "🐸", "👾", "🚀", "🎮", "⭐", "🔥", "🍕")

data class AppItem(val pkg: String, val label: String, val icon: ImageBitmap, val isGame: Boolean)

/** Единое действие: его порождают и геймпад, и клавиатура. */
enum class Act { Left, Right, Up, Down, Ok, Back, Alt, Sort, Prev, Next }

enum class SortMode(val title: String) { Alpha("А–Я"), Recent("Недавние"), Time("По времени") }

/** Игра, которая сейчас запускается: нужна для анимации «плитка → весь экран». */
class Launching(val app: AppItem, val bounds: Rect)

fun letterOf(a: AppItem): Char {
    val c = a.label.trim().firstOrNull()?.uppercaseChar() ?: '#'
    return if (c.isLetter()) c else '#'
}

fun fmtTime(ms: Long): String {
    val m = ms / 60_000
    return when {
        m < 1 -> "—"
        m < 60 -> "$m мин"
        else -> "${m / 60} ч ${m % 60} мин"
    }
}

fun fmtAgo(ts: Long): String {
    if (ts <= 0) return "ещё не запускалась"
    val d = (System.currentTimeMillis() - ts) / 86_400_000L
    return when { d < 1 -> "сегодня"; d == 1L -> "вчера"; else -> "$d дн. назад" }
}

/** Настройки, профиль и файлы обложек. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("hub", Context.MODE_PRIVATE)
    private val covers = File(ctx.filesDir, "covers").apply { mkdirs() }
    private val avatarFile = File(ctx.filesDir, "avatar.jpg")

    var nick: String
        get() = prefs.getString("nick", "Игрок") ?: "Игрок"
        set(v) = prefs.edit().putString("nick", v).apply()
    var emoji: String
        get() = prefs.getString("emoji", EMOJIS[0]) ?: EMOJIS[0]
        set(v) = prefs.edit().putString("emoji", v).apply()
    var swapAB: Boolean
        get() = prefs.getBoolean("swapAB", false)
        set(v) = prefs.edit().putBoolean("swapAB", v).apply()
    var sort: SortMode
        get() = SortMode.values().getOrElse(prefs.getInt("sort", 0)) { SortMode.Alpha }
        set(v) = prefs.edit().putInt("sort", v.ordinal).apply()

    fun loadHome(): List<String>? =
        prefs.getString("home", null)?.split("|")?.filter { it.isNotEmpty() }
    fun saveHome(list: List<String>) = prefs.edit().putString("home", list.joinToString("|")).apply()

    fun loadCovers(): Map<String, ImageBitmap> =
        covers.listFiles().orEmpty().mapNotNull { f ->
            BitmapFactory.decodeFile(f.path)?.let { f.nameWithoutExtension to it.asImageBitmap() }
        }.toMap()
    fun saveCover(pkg: String, bmp: Bitmap) {
        File(covers, "$pkg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
    }
    fun deleteCover(pkg: String) { File(covers, "$pkg.jpg").delete() }

    fun loadAvatar(): ImageBitmap? =
        if (avatarFile.exists()) BitmapFactory.decodeFile(avatarFile.path)?.asImageBitmap() else null
    fun saveAvatar(bmp: Bitmap) {
        avatarFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }
    fun deleteAvatar() { avatarFile.delete() }
}
