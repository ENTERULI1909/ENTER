package com.example.consolehub

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val store = Store(ctx)
    private val play = PlayTime(ctx)
    private val collator = Collator.getInstance(Locale.forLanguageTag("ru"))

    // ---- данные ----
    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var covers by mutableStateOf<Map<String, ImageBitmap>>(emptyMap())
    private var savedHome by mutableStateOf(store.loadHome())
    var playMs by mutableStateOf<Map<String, Long>>(emptyMap())
    var lastPlayed by mutableStateOf<Map<String, Long>>(emptyMap())
    var hasUsage by mutableStateOf(false)

    // ---- профиль и настройки ----
    var nick by mutableStateOf(store.nick)
    var emoji by mutableStateOf(store.emoji)
    var avatar by mutableStateOf<ImageBitmap?>(null)
    var swapAB by mutableStateOf(store.swapAB)
    var sortMode by mutableStateOf(store.sort)

    // ---- состояние экранов ----
    var started by mutableStateOf(false)      // false = стартовый экран
    var inLib by mutableStateOf(false)
    var homeIndex by mutableIntStateOf(0)
    var libIndex by mutableIntStateOf(0)
    var libJumpTick by mutableIntStateOf(0)
    var padActive by mutableStateOf(false)
    var sheet by mutableStateOf<AppItem?>(null)
    var sheetItems by mutableStateOf<List<Pair<String, () -> Unit>>>(emptyList())
    var sheetIndex by mutableIntStateOf(0)
    var settingsOpen by mutableStateOf(false)
    var settingsIndex by mutableIntStateOf(0)
    var typing by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var resumeTick by mutableIntStateOf(0)

    // ---- запросы к Activity ----
    var coverRequest by mutableStateOf<String?>(null)
    var avatarRequest by mutableIntStateOf(0)
    var usageRequest by mutableIntStateOf(0)
    var nickFocusTick by mutableIntStateOf(0)
    var onTick: (() -> Unit)? = null
    var starter: ((Intent) -> Unit)? = null

    // ---- запуск игры ----
    var launching by mutableStateOf<Launching?>(null)
    var selBounds: Rect = Rect.Zero

    val library: List<AppItem> by derivedStateOf {
        when (sortMode) {
            SortMode.Alpha -> apps.sortedWith { a, b -> collator.compare(a.label, b.label) }
            SortMode.Recent -> apps.sortedWith(
                compareByDescending<AppItem> { lastPlayed[it.pkg] ?: 0L }.thenBy { it.label.lowercase() })
            SortMode.Time -> apps.sortedWith(
                compareByDescending<AppItem> { playMs[it.pkg] ?: 0L }.thenBy { it.label.lowercase() })
        }
    }
    /** Индексы, с которых начинается каждая буква (только при сортировке А–Я). */
    val groupStarts: List<Int> by derivedStateOf {
        if (sortMode != SortMode.Alpha) emptyList()
        else library.indices.filter { it == 0 || letterOf(library[it]) != letterOf(library[it - 1]) }
    }

    init {
        refresh()
        viewModelScope.launch(Dispatchers.IO) {
            val c = store.loadCovers()
            val a = store.loadAvatar()
            withContext(Dispatchers.Main) { covers = c; avatar = a }
        }
    }

    // ---------- загрузка ----------

    fun refresh() {
        viewModelScope.launch(Dispatchers.Default) {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .map { ri ->
                    AppItem(
                        pkg = ri.activityInfo.packageName,
                        label = ri.loadLabel(pm).toString(),
                        icon = ri.loadIcon(pm).toBitmap(192, 192).asImageBitmap(),
                        isGame = ri.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME,
                    )
                }
                .distinctBy { it.pkg }
            withContext(Dispatchers.Main) { apps = list }
        }
    }

    /** Вызывается при каждом возврате в приложение: в том числе из игры. */
    fun onResume() {
        resumeTick++
        viewModelScope.launch(Dispatchers.IO) {
            val (t, l) = play.sync()
            val access = play.hasAccess()
            withContext(Dispatchers.Main) { playMs = t; lastPlayed = l; hasUsage = access }
        }
    }

    private fun defaultHome() = apps.filter { it.isGame }.ifEmpty { apps }.take(6).map { it.pkg }
    fun homePkgs(): List<String> = savedHome ?: defaultHome()
    val home: List<AppItem>
        get() {
            val m = apps.associateBy { it.pkg }
            return homePkgs().mapNotNull { m[it] }
        }
    val homeSel: Int get() = homeIndex.coerceIn(0, (home.size - 1).coerceAtLeast(0))

    // ---------- общее ----------

    fun toast(t: String) {
        message = t
        viewModelScope.launch { delay(1800); if (message == t) message = null }
    }

    /** Стартовый экран → главное меню. */
    fun begin() {
        if (started) return
        started = true
        onTick?.invoke()
        viewModelScope.launch {
            delay(1200)
            if (!hasUsage) toast("Чтобы считать время игры, включи доступ в профиле (Y)")
        }
    }

    // ---------- запуск игры ----------

    fun start(app: AppItem, from: Rect? = null) {
        if (launching != null) return
        if (ctx.packageManager.getLaunchIntentForPackage(app.pkg) == null) {
            toast("Не удалось запустить: ${app.label}"); return
        }
        launching = Launching(app, from ?: selBounds)
        onTick?.invoke()
    }

    /** Анимация дошла до конца: открываем игру и ещё чуть держим затемнение. */
    fun finishLaunch() {
        val l = launching ?: return
        val i = ctx.packageManager.getLaunchIntentForPackage(l.app.pkg)
        if (i == null) { launching = null; return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        starter?.invoke(i) ?: ctx.startActivity(i)
        viewModelScope.launch { delay(700); launching = null }
    }

    // ---------- навигация ----------

    fun selectHome(i: Int) { homeIndex = i.coerceIn(0, (home.size - 1).coerceAtLeast(0)) }
    fun moveHome(d: Int) {
        val n = (homeSel + d).coerceIn(0, (home.size - 1).coerceAtLeast(0))
        if (n != homeSel) { homeIndex = n; onTick?.invoke() }
    }
    private fun moveLib(d: Int) {
        val n = (libIndex + d).coerceIn(0, (library.size - 1).coerceAtLeast(0))
        if (n != libIndex) { libIndex = n; onTick?.invoke() }
    }
    fun jumpTo(i: Int) { libIndex = i.coerceIn(0, (library.size - 1).coerceAtLeast(0)); libJumpTick++; onTick?.invoke() }
    private fun jumpGroup(dir: Int) {
        val s = groupStarts
        if (s.isEmpty()) { moveLib(dir * COLS * 2); return }
        val cur = s.lastOrNull { it <= libIndex } ?: 0
        val target = if (dir > 0) {
            s.firstOrNull { it > libIndex } ?: s.last()
        } else if (libIndex > cur) cur else (s.lastOrNull { it < cur } ?: 0)
        jumpTo(target)
    }

    fun openLibrary() { inLib = true; onTick?.invoke() }
    fun closeLibrary() { if (inLib) { inLib = false; onTick?.invoke() } }

    fun setSort(m: SortMode) {
        sortMode = m; store.sort = m
        libIndex = 0; libJumpTick++
    }
    private fun cycleSort() {
        setSort(SortMode.values()[(sortMode.ordinal + 1) % SortMode.values().size])
        toast("Сортировка: ${sortMode.title}")
    }

    // ---------- главный экран и обложки ----------

    fun toggleHome(app: AppItem) {
        val cur = homePkgs().toMutableList()
        if (app.pkg in cur) {
            if (cur.size < 2) { toast("На главном должна остаться хотя бы одна игра"); return }
            cur.remove(app.pkg); toast("Убрано с главного: ${app.label}")
        } else {
            cur.add(app.pkg); toast("Добавлено на главный: ${app.label}")
        }
        savedHome = cur
        store.saveHome(cur)
    }

    private fun squareBitmap(uri: Uri, size: Int): Bitmap? {
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        val s = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        return Bitmap.createScaledBitmap(sq, size, size, true)
    }

    fun setCover(pkg: String, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val out = squareBitmap(uri, 320) ?: return@launch
            store.saveCover(pkg, out)
            withContext(Dispatchers.Main) { covers = covers + (pkg to out.asImageBitmap()); toast("Обложка обновлена") }
        }
    }
    private fun removeCover(pkg: String) { store.deleteCover(pkg); covers = covers - pkg; toast("Обложка сброшена") }

    fun openSheet(app: AppItem) {
        sheet = app
        sheetIndex = 0
        sheetItems = buildList {
            add((if (app.pkg in homePkgs()) "Убрать с главного экрана" else "Добавить на главный экран") to { toggleHome(app) })
            add("Выбрать обложку из галереи" to { coverRequest = app.pkg })
            if (app.pkg in covers) add("Вернуть стандартную" to { removeCover(app.pkg) })
            add("Отмена" to {})
        }
        onTick?.invoke()
    }
    fun closeSheet() { sheet = null }
    fun runSheet(i: Int) {
        val action = sheetItems.getOrNull(i)?.second
        sheet = null
        action?.invoke()
    }

    // ---------- профиль ----------

    fun openSettings() { settingsOpen = true; settingsIndex = 0; onTick?.invoke() }
    fun closeSettings() { settingsOpen = false; typing = false }
    fun setNick(v: String) { nick = v.take(16); store.nick = nick }
    fun setEmoji(e: String) {
        emoji = e; store.emoji = e
        if (avatar != null) { store.deleteAvatar(); avatar = null }
    }
    fun setAvatarPhoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val out = squareBitmap(uri, 256) ?: return@launch
            store.saveAvatar(out)
            withContext(Dispatchers.Main) { avatar = out.asImageBitmap() }
        }
    }
    fun removeAvatarPhoto() { store.deleteAvatar(); avatar = null }
    fun toggleSwap() { swapAB = !swapAB; store.swapAB = swapAB }

    // ---------- единая точка ввода: геймпад, клавиатура, кнопки ----------

    fun act(a: Act) {
        padActive = true
        if (!started) { begin(); return }
        if (launching != null) return

        if (settingsOpen) {
            when (a) {
                Act.Up -> settingsIndex = (settingsIndex - 1 + SETTINGS_ROWS) % SETTINGS_ROWS
                Act.Down -> settingsIndex = (settingsIndex + 1) % SETTINGS_ROWS
                Act.Left, Act.Right -> if (settingsIndex == 1) {
                    val i = EMOJIS.indexOf(emoji).coerceAtLeast(0)
                    setEmoji(EMOJIS[(i + (if (a == Act.Right) 1 else EMOJIS.size - 1)) % EMOJIS.size])
                }
                Act.Ok -> when (settingsIndex) {
                    0 -> nickFocusTick++
                    2 -> if (avatar != null) removeAvatarPhoto() else avatarRequest++
                    3 -> usageRequest++
                    4 -> toggleSwap()
                    5 -> closeSettings()
                    else -> {}
                }
                Act.Back -> closeSettings()
                else -> {}
            }
            return
        }
        if (sheet != null) {
            val n = sheetItems.size
            when (a) {
                Act.Up -> sheetIndex = (sheetIndex - 1 + n) % n
                Act.Down -> sheetIndex = (sheetIndex + 1) % n
                Act.Ok -> runSheet(sheetIndex)
                Act.Back -> closeSheet()
                else -> {}
            }
            return
        }
        if (!inLib) {
            when (a) {
                Act.Left -> moveHome(-1)
                Act.Right -> moveHome(1)
                Act.Prev -> moveHome(-3)
                Act.Next -> moveHome(3)
                Act.Down -> openLibrary()
                Act.Ok -> home.getOrNull(homeSel)?.let { start(it) }
                Act.Alt -> home.getOrNull(homeSel)?.let { openSheet(it) }
                Act.Sort -> openSettings()
                else -> {}
            }
        } else {
            when (a) {
                Act.Left -> moveLib(-1)
                Act.Right -> moveLib(1)
                Act.Down -> moveLib(COLS)
                Act.Up -> if (libIndex < COLS) closeLibrary() else moveLib(-COLS)
                Act.Prev -> jumpGroup(-1)
                Act.Next -> jumpGroup(1)
                Act.Ok -> library.getOrNull(libIndex)?.let { start(it) }
                Act.Alt -> library.getOrNull(libIndex)?.let { openSheet(it) }
                Act.Sort -> cycleSort()
                Act.Back -> closeLibrary()
            }
        }
    }
}
